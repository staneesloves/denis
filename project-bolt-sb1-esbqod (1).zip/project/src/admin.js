import { storage } from './utils/storage.js';

export function initAdmin() {
  const balances = storage.get('balances');
  const transactions = storage.get('transactions');

  const template = `
    <div class="admin-container">
      <nav class="top-nav">
        <h2>Admin Panel</h2>
        <button onclick="handleLogout()">Logout</button>
      </nav>

      <div class="admin-section">
        <h3>Update Balance</h3>
        <div class="admin-form">
          <select id="clientSelect">
            ${Object.keys(balances).map(client => 
              `<option value="${client}">${client}</option>`
            ).join('')}
          </select>
          <input type="number" id="amount" placeholder="Amount" />
          <select id="transactionType">
            <option value="deposit">Deposit</option>
            <option value="withdrawal">Withdrawal</option>
          </select>
          <input type="text" id="description" placeholder="Description" />
          <button onclick="handleTransaction()">Update</button>
        </div>
      </div>

      <div class="client-balances">
        <h3>Current Balances</h3>
        <table>
          <thead>
            <tr>
              <th>Client</th>
              <th>Balance</th>
            </tr>
          </thead>
          <tbody>
            ${Object.entries(balances).map(([client, balance]) => `
              <tr>
                <td>${client}</td>
                <td>$${balance}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;

  // Add transaction handler to window
  window.handleTransaction = () => {
    const client = document.getElementById('clientSelect').value;
    const amount = Number(document.getElementById('amount').value);
    const type = document.getElementById('transactionType').value;
    const description = document.getElementById('description').value;

    if (!amount || !description) {
      alert('Please fill all fields');
      return;
    }

    // Update balance
    const balances = storage.get('balances');
    balances[client] = type === 'deposit' 
      ? balances[client] + amount 
      : balances[client] - amount;
    storage.set('balances', balances);

    // Add transaction
    const transactions = storage.get('transactions');
    if (!transactions[client]) transactions[client] = [];
    transactions[client].push({
      date: new Date().toISOString().split('T')[0],
      type,
      amount,
      description
    });
    storage.set('transactions', transactions);

    // Refresh page
    window.location.reload();
  };

  return template;
}