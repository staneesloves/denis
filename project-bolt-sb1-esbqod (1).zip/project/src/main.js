import './style.css';
import { initAuth } from './auth.js';
import { initDashboard } from './dashboard.js';
import { initAdmin } from './admin.js';

// Initialize the application
function init() {
  const app = document.querySelector('#app');
  
  // Router based on hash
  window.addEventListener('hashchange', () => updateView());
  window.addEventListener('load', () => updateView());

  function updateView() {
    const hash = window.location.hash || '#login';
    
    switch(hash) {
      case '#login':
        app.innerHTML = initAuth();
        break;
      case '#dashboard':
        if (!localStorage.getItem('currentUser')) {
          window.location.hash = '#login';
          return;
        }
        app.innerHTML = initDashboard();
        break;
      case '#admin':
        if (localStorage.getItem('currentUser') !== 'admin') {
          window.location.hash = '#login';
          return;
        }
        app.innerHTML = initAdmin();
        break;
    }
  }
}

init();