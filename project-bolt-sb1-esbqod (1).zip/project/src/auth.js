import { storage } from './utils/storage.js';

export function initAuth() {
  // Demo credentials
  const users = {
    'admin': 'admin123',
    'client1': 'pass123',
    'client2': 'pass123'
  };

  // Store demo data if not exists
  if (!storage.get('users')) {
    storage.set('users', users);
    
    // Initialize demo balances
    storage.set('balances', {
      'client1': 1000,
      'client2': 2000
    });
    
    // Initialize demo transactions
    storage.set('transactions', {
      'client1': [
        { date: '2024-01-01', type: 'deposit', amount: 1000, description: 'Initial deposit' }
      ],
      'client2': [
        { date: '2024-01-01', type: 'deposit', amount: 2000, description: 'Initial deposit' }
      ]
    });
  }

  const template = `
    <div class="auth-container">
      <h1>Client Balance Tracker</h1>
      <div class="auth-form">
        <input type="text" id="username" placeholder="Username" />
        <input type="password" id="password" placeholder="Password" />
        <button onclick="handleLogin()">Login</button>
      </div>
    </div>
  `;

  // Add login handler to window
  window.handleLogin = () => {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const storedUsers = storage.get('users');

    if (storedUsers[username] === password) {
      storage.set('currentUser', username);
      window.location.hash = username === 'admin' ? '#admin' : '#dashboard';
    } else {
      alert('Invalid credentials');
    }
  };

  return template;
}