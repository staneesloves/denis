import { storage } from './utils/storage.js';

export function initDashboard() {
  const currentUser = storage.get('currentUser');
  const balances = storage.get('balances');
  const transactions = storage.get('transactions');
  
  const userBalance = balances[currentUser] || 0;
  const userTransactions = transactions[currentUser] || [];

  const transactionsHtml = userTransactions
    .map(t => `
      <tr>
        <td>${t.date}</td>
        <td>${t.type}</td>
        <td>$${t.amount}</td>
        <td>${t.description}</td>
      </tr>
    `)
    .join('');

  const template = `
    <div class="dashboard-container">
      <nav class="top-nav">
        <h2>Welcome, ${currentUser}</h2>
        <button onclick="handleLogout()">Logout</button>
      </nav>
      
      <div class="balance-card">
        <h3>Current Balance</h3>
        <div class="balance-amount">$${userBalance}</div>
      </div>

      <div class="transactions-section">
        <h3>Transaction History</h3>
        <table class="transactions-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Type</th>
              <th>Amount</th>
              <th>Description</th>
            </tr>
          </thead>
          <tbody>
            ${transactionsHtml}
          </tbody>
        </table>
      </div>
    </div>
  `;

  // Add logout handler to window
  window.handleLogout = () => {
    storage.remove('currentUser');
    window.location.hash = '#login';
  };

  return template;
}